<?php 

$koneksi =  new mysqli("dns3.simplecplogin.com", "slkbank_umhukum", "mhaQ?bA9Jhk4", "slkbank_hukum");
?>